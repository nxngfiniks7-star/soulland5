package com.soulland.mod;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketSync implements IMessage {
    public int soul, level, exp, rings, mana, selected;

    public PacketSync() {}

    public PacketSync(int soul, int level, int exp, int rings, int mana, int selected) {
        this.soul = soul; this.level = level; this.exp = exp;
        this.rings = rings; this.mana = mana; this.selected = selected;
    }

    @Override public void fromBytes(ByteBuf b) {
        soul = b.readInt(); level = b.readInt(); exp = b.readInt();
        rings = b.readInt(); mana = b.readInt(); selected = b.readInt();
    }

    @Override public void toBytes(ByteBuf b) {
        b.writeInt(soul); b.writeInt(level); b.writeInt(exp);
        b.writeInt(rings); b.writeInt(mana); b.writeInt(selected);
    }

    public static class Handler implements IMessageHandler<PacketSync, IMessage> {
        @Override
        public IMessage onMessage(PacketSync m, MessageContext ctx) {
            Minecraft.getMinecraft().addScheduledTask(() -> {
                ClientState.soul = m.soul; ClientState.level = m.level; ClientState.exp = m.exp;
                ClientState.rings = m.rings; ClientState.mana = m.mana; ClientState.selected = m.selected;
            });
            return null;
        }
    }
}
