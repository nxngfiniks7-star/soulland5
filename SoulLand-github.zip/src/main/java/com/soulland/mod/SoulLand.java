package com.soulland.mod;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = SoulLand.MODID, name = "Soul Land", version = "1.0.0", acceptedMinecraftVersions = "[1.12.2]")
public class SoulLand {
    public static final String MODID = "soulland";

    @SidedProxy(clientSide = "com.soulland.mod.ClientProxy", serverSide = "com.soulland.mod.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        NetworkHandler.init();
        proxy.preInit();
    }
}
