package com.soulland.mod;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;

/** ลูกแก้วรีวิญญาณยุทธ์: สุ่มวิญญาณยุทธ์ใหม่ (ไม่ซ้ำของเดิม) เลเวลและวงแหวนยังอยู่ครบ */
public class ItemSoulReset extends Item {
    public ItemSoulReset() { setMaxStackSize(16); }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World w, EntityPlayer p, EnumHand h) {
        ItemStack s = p.getHeldItem(h);
        if (!w.isRemote) {
            EntityPlayerMP mp = (EntityPlayerMP) p;
            int cur = SoulData.getSoul(mp);
            if (cur == 0) {
                mp.sendStatusMessage(new TextComponentTranslation("msg.soulland.needawaken"), true);
                return new ActionResult<>(EnumActionResult.FAIL, s);
            }
            int soul = SoulData.rollSoul(w.rand, cur);
            SoulData.setSoul(mp, soul);
            int n = SoulSkills.next(soul, SoulData.getRings(mp), -1);
            SoulData.setSelected(mp, Math.max(0, n));
            SoulData.sync(mp);
            SoulData.syncVisual(mp);
            mp.sendMessage(new TextComponentTranslation("msg.soulland.reroll", new TextComponentTranslation("soul.soulland." + soul)));
            if (soul == 3) mp.sendMessage(new TextComponentTranslation("msg.soulland.twin"));
            if (!p.capabilities.isCreativeMode) s.shrink(1);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, s);
    }
}
