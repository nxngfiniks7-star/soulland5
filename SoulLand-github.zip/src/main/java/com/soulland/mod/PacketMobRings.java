package com.soulland.mod;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** วงแหวนของสัตว์วิญญาณ (มอนสเตอร์) */
public class PacketMobRings implements IMessage {
    public int entityId;
    public int[] tiers = new int[0];

    public PacketMobRings() {}

    public PacketMobRings(int entityId, int[] tiers) { this.entityId = entityId; this.tiers = tiers; }

    @Override public void fromBytes(ByteBuf b) {
        entityId = b.readInt();
        int n = Math.min(9, b.readByte());
        tiers = new int[n];
        for (int i = 0; i < n; i++) tiers[i] = b.readByte();
    }

    @Override public void toBytes(ByteBuf b) {
        b.writeInt(entityId);
        int n = Math.min(9, tiers.length);
        b.writeByte(n);
        for (int i = 0; i < n; i++) b.writeByte(tiers[i]);
    }

    public static class Handler implements IMessageHandler<PacketMobRings, IMessage> {
        @Override
        public IMessage onMessage(PacketMobRings m, MessageContext ctx) {
            Minecraft.getMinecraft().addScheduledTask(() -> {
                if (m.tiers.length == 0) ClientState.mobRings.remove(m.entityId);
                else ClientState.mobRings.put(m.entityId, m.tiers);
            });
            return null;
        }
    }
}
